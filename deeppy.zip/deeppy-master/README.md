## Deep learning in Python

DeepPy is a Pythonic deep learning framework built on top of NumPy ([with CUDA acceleration][cudarray]).

Read more on the [preliminary website][website].

[website]: http://andersbll.github.io/deeppy-website/
[cudarray]: http://github.com/andersbll/cudarray
