from .adversarial import AdversarialNet
from .feedforward import FeedForwardNet, ClassifierNet, RegressorNet
from .variational_autoencoder import VariationalAutoencoder
