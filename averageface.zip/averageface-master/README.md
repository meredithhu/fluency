averageface
===========

Python tool for creating average images from faces